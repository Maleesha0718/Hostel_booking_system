/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

/**
 *
 * @author HP
 */
public class Bookings {

   
    
       private String Student_ID,Owner_ID,Room_ID,No_of_rooms,Student_Phone_NO;

       
       public Bookings (String Student_ID,String Owner_ID,String Room_ID,String No_of_rooms,String Student_Phone_NO)
    {
    this.Student_ID=Student_ID;
    this.Owner_ID=Owner_ID;
    this.Room_ID=Room_ID;
    this.No_of_rooms=No_of_rooms;
    this.Student_Phone_NO=Student_Phone_NO;
    
    }
      
       
       
       public String getStudent_ID()
    {
        return Student_ID;
    }
    public String getOwner_ID()
    {
        return Owner_ID;
    }
    
    public String getRoom_ID()
    {
        return Room_ID;
    }
    
    public String getNo_of_rooms()
    {
        return No_of_rooms;
    }
    
    public String getStudent_Phone_NO()
    {
        return Student_Phone_NO;
    }
}
    

