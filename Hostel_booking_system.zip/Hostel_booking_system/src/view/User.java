/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

/**
 *
 * @author Maleesha
 */
class User {
    

    
   private String Room_ID,Hostal_Owner_ID,Hostal_name,Distence,Location,Room_Size,Facilities,Electricity,Type,Price_for_one_person,Price_for_two_people,Price_for_three_people,Price_for_four_people,Discription,Number_of_rooms;
    
    public User (String Room_ID,String Hostal_Owner_ID,String Hostal_name,String Distence,String Location,String Room_Size,String Facilities,String Electricity,String Type,String Price_for_one_person,String Price_for_two_people,String Price_for_three_people,String Price_for_four_people,String Discription,String Number_of_rooms)
    {
    this.Room_ID=Room_ID;
    this.Hostal_Owner_ID=Hostal_Owner_ID;
    this.Hostal_name=Hostal_name;
    this.Distence=Distence;
    this.Location=Location;
    this.Room_Size=Room_Size;
    this.Facilities=Facilities;
    this.Electricity=Electricity;
    this.Type=Type;
    this.Price_for_one_person=Price_for_one_person;
    this.Price_for_two_people=Price_for_two_people;
    this.Price_for_three_people=Price_for_three_people;
    this.Price_for_four_people=Price_for_four_people;
    this.Discription=Discription;
    this.Number_of_rooms=Number_of_rooms;
    
    }

   
    

    
    public String getRoom_ID()
    {
        return Room_ID;
    }
    
    public String getHostal_name()
    {
        return Hostal_name;
    }
    
    public String getHostal_Owner_ID()
    {
        return Hostal_Owner_ID;
    }
    
    public String getDistence()
    {
        return Distence;
    }
    public String getLocation()
    {
        return Location;
    }
    public String getRoom_Size()
    {
        return Room_Size;
    }
    public String getFacilities()
    {
        return Facilities;
    }
    public String getElectricity()
    {
        return Electricity;
    }
    public String getType()
    {
        return Type;
    }
    public String getPrice_for_one_person()
    {
        return Price_for_one_person;
    }
    public String getPrice_for_two_people()
    {
        return Price_for_two_people;
    }
    public String getPrice_for_three_people()
    {
        return Price_for_three_people;
    }
    public String getPrice_for_four_people()
    {
        return Price_for_four_people;
    }
    public String getDiscription()
    {
        return Discription;
    }
    public String getNumber_of_rooms()
    {
        return Number_of_rooms;
    }

    
}
