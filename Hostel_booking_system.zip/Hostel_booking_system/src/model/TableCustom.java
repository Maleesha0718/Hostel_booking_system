/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.swing.JScrollPane;

/**
 *
 * @author Maleesha
 */
public class TableCustom {
    
    public enum TableType {
        MULTI_LINE, DEFAULT

        
    }

    public TableCustom() {
        
    }

    public static void apply(JScrollPane scroll, TableType type) {
        
        
    }
    
}
