/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Maleesha
 */
public class Hostal_Owner {
    
    private int Phone_Number;
    
   private String Hostal_Owner_ID,Name,Gender,Email;
    public Hostal_Owner (String Hostal_Owner_ID,String Name,String Gender,int Phone_Number,String Email)
    {
   
    this.Hostal_Owner_ID=Hostal_Owner_ID;
    this.Name=Name;
    this.Gender=Gender;
    this.Phone_Number=Phone_Number;
    this.Email=Email;
    }

    
    
    public String getHostal_Owner_ID()
    {
        return Hostal_Owner_ID;
    }
    
     public String getName()
    {
        return Name;
    }
     
    public String getGender()
    {
        return Gender;
    }
    
    public int getPhone_Number()
    {
        return Phone_Number;
    }
    
    public String getEmail()
    {
        return Email;
    }
   
}
