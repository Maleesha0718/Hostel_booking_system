/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Maleesha
 */
public class Student {
    private int Phone_Number;
    
   private String Student_ID,Name,Gender,Email;
   public Student (String Student_ID,String Name,String Gender,int Phone_Number,String Email)
    {
   
    this.Student_ID=Student_ID;
    this.Name=Name;
    this.Gender=Gender;
    this.Phone_Number=Phone_Number;
    this.Email=Email;
    }

    
    
    public String getStudent_ID()
    {
        return Student_ID;
    }
    
     public String getName()
    {
        return Name;
    }
     
    public String getGender()
    {
        return Gender;
    }
    
    public int getPhone_Number()
    {
        return Phone_Number;
    }
    
    public String getEmail()
    {
        return Email;
    }
    
}
